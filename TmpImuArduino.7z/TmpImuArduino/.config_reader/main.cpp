#include <iostream>
#include <string>

#include "ConfigReader.hpp"
#include "Exception.hpp"
#include "ConfigReader.tcc"
#include "OptionAdapter.hpp"
#include "EnumClasses.hpp"

int main() {
    ConfigReader* pConf = ConfigReader::GetInstance();
    OptionAdapter optionAdapter;

    const std::string baudRateTag = "Baud_rate";
    const std::string numberTag = "Number";
    const std::string nameTag = "Name";
    const std::string numDataBitsTag = "Number_of_data_bits";

    const int defaultBaudRateValue = 9600;
    const int defaultNumberValue = 314;
    const std::string defaultNameValue = "Tux";
    const int defaultNumDataBitsValue = 6;
    
    pConf->SaveDefaultTagValue(baudRateTag, defaultBaudRateValue);
    pConf->SaveDefaultTagValue(numberTag, defaultNumberValue);
    pConf->SaveDefaultTagValue(nameTag, defaultNameValue);
    pConf->SaveDefaultTagValue(numDataBitsTag, defaultNumDataBitsValue);

    try {
        pConf->ParseConfig();
    } catch (Exception& exp) {
        std::cout << exp.what() << '\n';
        pConf->ReleaseInstance();
        return 1;
    }

    std::cout << "Number of data bits: " << pConf->GetValue<int>(numDataBitsTag) << '\n';
    std::cout << "Name = " << pConf->GetValue<std::string>(nameTag) << '\n';

    if (optionAdapter.GetNumDataBitsEnum(pConf->GetValue<int>(numDataBitsTag)) == NumDataBits::EIGHT)
        std::cout << "Number of data bits in packet is eight.\n";
    else
        std::cout << "Number of data bits in packet is: " << pConf->GetValue<int>(numDataBitsTag) << '\n';

    pConf->ReleaseInstance();
    return 0;
}
