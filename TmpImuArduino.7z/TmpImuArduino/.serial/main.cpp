#include <iostream>
#include <chrono>
#include <string>
#include <thread>
#include <vector>

#include "Serial.hpp"
#include "EnumClasses.hpp"
#include "Exception.hpp"

int main() {
    const std::string device = "/dev/ttyACM0";
    const auto initTimeout = std::chrono::milliseconds(2000);
    char data;
    std::vector<std::string> readBuffer;
    const speed_t baudRate = 115200;

    _Serial mySerial;
    mySerial.SetDevice(device);
    mySerial.SetBaudRate(baudRate);
    mySerial.Open();
    mySerial.FlushSerialBuffers();

    const auto initStart = std::chrono::steady_clock::now();

    while (std::chrono::steady_clock::now() <= initStart + initTimeout) {
        if (mySerial.Available() > 0) {
            mySerial.Read(data);
            if (data == 'i') {
                std::cout << "Init was successful: " << data << '\n';
                break;
            } else {
                mySerial.FlushReceiverBuffer();
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    mySerial.FlushReceiverBuffer();

    int i = 0;
    std::string tmpBuffer;
    while (i < 10000) {
        mySerial.Read(data);
        if (data != '\r') {
            tmpBuffer.push_back(data);
        } else {
            readBuffer.push_back(tmpBuffer);
            tmpBuffer.clear();
            i++;
        }
    }
    
    i = 0;
    for (std::string& it : readBuffer) {
        std::cout << "[" << i << "]: " << it << '\n';
        i++;
    }

    mySerial.Close();
    return 0;
}
